/**
 * BarberTurno API — Modelo de Usuario
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Simula una base de datos de usuarios en memoria.
 * En producción, esta capa se reemplazaría por MySQL con Sequelize o similar.
 *
 * Estructura de cada usuario:
 *  - id       {number}  Identificador único autogenerado
 *  - nombre   {string}  Nombre completo del usuario
 *  - email    {string}  Correo electrónico (usado como clave de búsqueda)
 *  - password {string}  Hash bcrypt de la contraseña (nunca texto plano)
 *  - rol      {string}  'cliente' | 'admin'
 */

"use strict";

/* -------------------------------------------------------
   BASE DE DATOS EN MEMORIA
   Lista que persiste mientras el proceso Node está activo.
   ------------------------------------------------------- */
const usuarios = [
  {
    id: 1,
    nombre: "Frank Sepúlveda",
    email: "frank@email.com",
    // Hash bcrypt de "1234" (10 rondas)
    password: "$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy",
    rol: "cliente"
  },
  {
    id: 2,
    nombre: "Admin BarberTurno",
    email: "admin@barberturno.com",
    // Hash bcrypt de "admin123" (10 rondas)
    password: "$2a$10$TwBoT6S3RZqIUEbFNDMa9ObIJoHpIX2h/KjMiqeZ2kN.i/B0aWKMy",
    rol: "admin"
  }
];

/** Contador para IDs autogenerados */
let nextId = 3;

/* -------------------------------------------------------
   MÉTODOS DEL MODELO
   Interfaz CRUD sobre la lista en memoria.
   ------------------------------------------------------- */

/**
 * Busca un usuario por su dirección de correo electrónico.
 * @param {string} email - Correo a buscar
 * @returns {Object|undefined} Usuario encontrado o undefined
 */
function buscarPorEmail(email) {
  return usuarios.find(u => u.email === email.toLowerCase().trim());
}

/**
 * Busca un usuario por su ID numérico.
 * @param {number} id - ID a buscar
 * @returns {Object|undefined} Usuario encontrado o undefined
 */
function buscarPorId(id) {
  return usuarios.find(u => u.id === id);
}

/**
 * Crea y almacena un nuevo usuario.
 * IMPORTANTE: la contraseña recibida ya debe ser un hash bcrypt.
 * @param {string} nombre   - Nombre completo
 * @param {string} email    - Correo electrónico
 * @param {string} hashPass - Contraseña hasheada con bcrypt
 * @param {string} [rol]    - Rol del usuario (por defecto 'cliente')
 * @returns {Object} Usuario creado (sin contraseña)
 */
function crearUsuario(nombre, email, hashPass, rol = "cliente") {
  const nuevo = {
    id: nextId++,
    nombre,
    email: email.toLowerCase().trim(),
    password: hashPass,
    rol
  };
  usuarios.push(nuevo);

  /* Retornar sin exponer el hash de la contraseña */
  const { password, ...usuarioPublico } = nuevo;
  return usuarioPublico;
}

/**
 * Retorna todos los usuarios (solo datos públicos, sin contraseñas).
 * Útil para pruebas y administración.
 * @returns {Array} Lista de usuarios sin campo password
 */
function listarTodos() {
  return usuarios.map(({ password, ...pub }) => pub);
}

/* -------------------------------------------------------
   EXPORTACIONES
   ------------------------------------------------------- */
module.exports = {
  buscarPorEmail,
  buscarPorId,
  crearUsuario,
  listarTodos
};
