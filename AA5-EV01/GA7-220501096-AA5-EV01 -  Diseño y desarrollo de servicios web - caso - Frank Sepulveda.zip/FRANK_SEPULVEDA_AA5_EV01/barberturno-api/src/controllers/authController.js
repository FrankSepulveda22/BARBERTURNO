/**
 * BarberTurno API — Controlador de Autenticación
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Contiene la lógica de negocio para:
 *  - POST /api/auth/registro  → Registrar nuevo usuario
 *  - POST /api/auth/login     → Iniciar sesión
 *
 * Flujo de registro:
 *  1. Validar campos requeridos (nombre, email, password)
 *  2. Verificar que el email no esté ya registrado
 *  3. Hashear la contraseña con bcrypt
 *  4. Guardar el usuario
 *  5. Generar token JWT y responder con datos del usuario
 *
 * Flujo de login:
 *  1. Validar campos requeridos (email, password)
 *  2. Buscar usuario por email
 *  3. Comparar contraseña ingresada con el hash almacenado
 *  4. Generar token JWT y responder con datos del usuario
 */

"use strict";

const bcrypt = require("bcryptjs");
const jwt    = require("jsonwebtoken");

const Usuario          = require("../models/Usuario");
const { JWT_SECRET, JWT_EXPIRES_IN, BCRYPT_SALT_ROUNDS } = require("../config/config");

/* -------------------------------------------------------
   HELPER: Generar Token JWT
   ------------------------------------------------------- */

/**
 * Crea y firma un token JWT con el payload del usuario.
 * @param {Object} usuario - Objeto con { id, email, rol }
 * @returns {string} Token JWT firmado
 */
function generarToken(usuario) {
  return jwt.sign(
    {
      id:    usuario.id,
      email: usuario.email,
      rol:   usuario.rol
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

/* -------------------------------------------------------
   SERVICIO DE REGISTRO
   POST /api/auth/registro
   Body: { nombre, email, password }
   ------------------------------------------------------- */

/**
 * Registra un nuevo usuario cliente en el sistema.
 *
 * Validaciones:
 *  - nombre, email y password son obligatorios
 *  - password debe tener al menos 6 caracteres
 *  - El email no puede estar ya registrado
 *
 * @param {import('express').Request}  req
 * @param {import('express').Response} res
 */
async function registro(req, res) {
  try {
    /* --- 1. Extraer y validar los campos del cuerpo --- */
    const { nombre, email, password } = req.body;

    /* Verificar que ningún campo obligatorio esté vacío */
    if (!nombre || !email || !password) {
      return res.status(400).json({
        exito:   false,
        mensaje: "Todos los campos son obligatorios: nombre, email y password."
      });
    }

    /* Verificar longitud mínima de contraseña */
    if (password.length < 6) {
      return res.status(400).json({
        exito:   false,
        mensaje: "La contraseña debe tener al menos 6 caracteres."
      });
    }

    /* Validación básica del formato de email */
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        exito:   false,
        mensaje: "El formato del correo electrónico no es válido."
      });
    }

    /* --- 2. Verificar que el email no esté ya registrado --- */
    const usuarioExistente = Usuario.buscarPorEmail(email);
    if (usuarioExistente) {
      return res.status(409).json({
        exito:   false,
        mensaje: "Este correo electrónico ya está registrado. Intenta iniciar sesión."
      });
    }

    /* --- 3. Hashear la contraseña antes de almacenarla --- */
    const hashPassword = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);

    /* --- 4. Crear y guardar el nuevo usuario --- */
    const nuevoUsuario = Usuario.crearUsuario(nombre, email, hashPassword);

    /* --- 5. Generar token JWT para autenticación inmediata --- */
    const token = generarToken(nuevoUsuario);

    /* --- Respuesta exitosa (201 Created) --- */
    return res.status(201).json({
      exito:   true,
      mensaje: "Usuario registrado correctamente. ¡Bienvenido a BarberTurno!",
      token,
      usuario: nuevoUsuario
    });

  } catch (error) {
    /* Error inesperado del servidor */
    console.error("[registro] Error:", error.message);
    return res.status(500).json({
      exito:   false,
      mensaje: "Error interno del servidor. Intenta nuevamente."
    });
  }
}

/* -------------------------------------------------------
   SERVICIO DE INICIO DE SESIÓN
   POST /api/auth/login
   Body: { email, password }
   ------------------------------------------------------- */

/**
 * Autentica un usuario existente y devuelve un token JWT.
 *
 * Validaciones:
 *  - email y password son obligatorios
 *  - El email debe corresponder a un usuario registrado
 *  - La contraseña debe coincidir con el hash almacenado
 *
 * NOTA DE SEGURIDAD: Se usa el mismo mensaje de error tanto para
 * "email no encontrado" como para "contraseña incorrecta", para no
 * revelar si un email está registrado (enumeración de usuarios).
 *
 * @param {import('express').Request}  req
 * @param {import('express').Response} res
 */
async function login(req, res) {
  try {
    /* --- 1. Extraer y validar los campos del cuerpo --- */
    const { email, password } = req.body;

    /* Verificar que ambos campos estén presentes */
    if (!email || !password) {
      return res.status(400).json({
        exito:   false,
        mensaje: "El email y la contraseña son obligatorios."
      });
    }

    /* --- 2. Buscar el usuario por email --- */
    const usuario = Usuario.buscarPorEmail(email);

    /* Si el email no existe, responder con error genérico (seguridad) */
    if (!usuario) {
      return res.status(401).json({
        exito:   false,
        mensaje: "Error en la autenticación: credenciales incorrectas."
      });
    }

    /* --- 3. Verificar que la contraseña coincida con el hash --- */
    const passwordValida = await bcrypt.compare(password, usuario.password);

    /* Si la contraseña no coincide, responder con error genérico */
    if (!passwordValida) {
      return res.status(401).json({
        exito:   false,
        mensaje: "Error en la autenticación: credenciales incorrectas."
      });
    }

    /* --- 4. Generar token JWT --- */
    const token = generarToken(usuario);

    /* Preparar datos del usuario sin exponer la contraseña */
    const { password: _, ...usuarioPublico } = usuario;

    /* --- Respuesta exitosa (200 OK) --- */
    return res.status(200).json({
      exito:   true,
      mensaje: "Autenticación satisfactoria. ¡Bienvenido, " + usuario.nombre + "!",
      token,
      usuario: usuarioPublico
    });

  } catch (error) {
    /* Error inesperado del servidor */
    console.error("[login] Error:", error.message);
    return res.status(500).json({
      exito:   false,
      mensaje: "Error interno del servidor. Intenta nuevamente."
    });
  }
}

/* -------------------------------------------------------
   EXPORTACIONES
   ------------------------------------------------------- */
module.exports = { registro, login };
