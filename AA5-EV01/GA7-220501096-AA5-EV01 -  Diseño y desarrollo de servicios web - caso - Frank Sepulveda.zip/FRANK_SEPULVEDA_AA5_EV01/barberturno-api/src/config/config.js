/**
 * BarberTurno API — Configuración general
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Centraliza las constantes de configuración del servidor.
 * En producción, los valores sensibles (SECRET, PORT) deben
 * cargarse desde variables de entorno con dotenv.
 */

"use strict";

module.exports = {
  /** Puerto en que escucha el servidor Express */
  PORT: process.env.PORT || 8080,

  /**
   * Clave secreta para firmar y verificar tokens JWT.
   * NUNCA exponer este valor en repositorios públicos.
   * En producción usar: process.env.JWT_SECRET
   */
  JWT_SECRET: process.env.JWT_SECRET || "barberturno_secret_ga7_aa5",

  /**
   * Tiempo de expiración del token JWT.
   * Formato: string de tiempo ('1h', '7d', '30m', etc.)
   */
  JWT_EXPIRES_IN: "8h",

  /**
   * Número de rondas de salt para bcrypt.
   * A mayor número, más seguro pero más lento.
   * Valor recomendado en producción: 12
   */
  BCRYPT_SALT_ROUNDS: 10
};
