/**
 * BarberTurno API — Middleware de Autenticación JWT
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Middleware que protege rutas privadas verificando el token JWT
 * enviado en el encabezado Authorization de la petición.
 *
 * Uso:
 *   router.get('/perfil', verificarToken, controlador.perfil);
 *
 * El cliente debe enviar el token así:
 *   Authorization: Bearer <token>
 *
 * Si el token es válido, adjunta los datos del usuario al objeto
 * req.usuario para que el controlador siguiente los use.
 */

"use strict";

const jwt = require("jsonwebtoken");
const { JWT_SECRET } = require("../config/config");

/**
 * Verifica que la petición incluya un token JWT válido y vigente.
 *
 * @param {import('express').Request}  req  - Objeto de solicitud HTTP
 * @param {import('express').Response} res  - Objeto de respuesta HTTP
 * @param {Function}                   next - Función para pasar al siguiente middleware
 */
function verificarToken(req, res, next) {
  /* Leer el encabezado Authorization */
  const authHeader = req.headers["authorization"];

  /* Verificar que el encabezado exista y tenga el formato "Bearer <token>" */
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      exito:   false,
      mensaje: "Acceso denegado. Se requiere token de autenticación."
    });
  }

  /* Extraer solo el token (sin el prefijo "Bearer ") */
  const token = authHeader.split(" ")[1];

  try {
    /* Verificar la firma y la expiración del token */
    const payload = jwt.verify(token, JWT_SECRET);

    /* Adjuntar el payload decodificado al request para uso posterior */
    req.usuario = payload; // { id, email, rol, iat, exp }

    /* Continuar con el siguiente middleware o controlador */
    next();

  } catch (error) {
    /* El token es inválido, ha expirado o fue manipulado */
    return res.status(401).json({
      exito:   false,
      mensaje: "Token inválido o expirado. Por favor, inicia sesión nuevamente."
    });
  }
}

/**
 * Middleware para restringir acceso solo a administradores.
 * Debe usarse DESPUÉS de verificarToken.
 *
 * @param {import('express').Request}  req
 * @param {import('express').Response} res
 * @param {Function}                   next
 */
function soloAdmin(req, res, next) {
  if (req.usuario?.rol !== "admin") {
    return res.status(403).json({
      exito:   false,
      mensaje: "Acceso denegado. Se requieren permisos de administrador."
    });
  }
  next();
}

module.exports = { verificarToken, soloAdmin };
