/**
 * BarberTurno API — Punto de entrada del servidor
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Configura y levanta el servidor Express con:
 *  - Parseo de JSON en el body de las peticiones
 *  - Cabeceras CORS para permitir llamadas desde el front-end
 *  - Ruta base de la API (/api/auth)
 *  - Manejador de rutas no encontradas (404)
 *  - Manejador global de errores (500)
 *
 * Para iniciar el servidor:
 *   node src/index.js          (producción)
 *   npx nodemon src/index.js   (desarrollo con recarga automática)
 */

"use strict";

const express = require("express");
const { PORT } = require("./config/config");

/* -------------------------------------------------------
   INICIALIZAR LA APLICACIÓN EXPRESS
   ------------------------------------------------------- */
const app = express();

/* -------------------------------------------------------
   MIDDLEWARES GLOBALES
   ------------------------------------------------------- */

/**
 * Parseo de JSON: permite leer req.body como objeto JavaScript
 * cuando el Content-Type es application/json.
 */
app.use(express.json());

/**
 * CORS manual: habilita peticiones desde el front-end BarberTurno
 * que corre en localhost o en GitHub Pages.
 * En producción, restringir el origen a dominios específicos.
 */
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin",  "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  /* Responder inmediatamente las peticiones preflight de CORS */
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});

/**
 * Logger básico: imprime en consola cada petición recibida.
 * Útil para depuración durante el desarrollo.
 */
app.use((req, _res, next) => {
  const ahora = new Date().toLocaleTimeString("es-CO");
  console.log(`[${ahora}] ${req.method} ${req.url}`);
  next();
});

/* -------------------------------------------------------
   RUTAS
   ------------------------------------------------------- */

/**
 * Ruta de salud: confirma que el servidor está funcionando.
 * GET /api/health
 */
app.get("/api/health", (_req, res) => {
  res.json({
    exito:    true,
    mensaje:  "BarberTurno API está en línea ✅",
    version:  "1.0.0 — GA7-220501096-AA5-EV01"
  });
});

/**
 * Rutas de autenticación (registro e inicio de sesión).
 * Prefijo: /api/auth
 *   POST /api/auth/registro
 *   POST /api/auth/login
 *   GET  /api/auth/perfil  (protegida con JWT)
 */
app.use("/api/auth", require("./routes/authRoutes"));

/* -------------------------------------------------------
   MANEJADORES DE ERROR
   ------------------------------------------------------- */

/**
 * 404 - Ruta no encontrada.
 * Se activa cuando ninguna ruta anterior coincide con la URL.
 */
app.use((_req, res) => {
  res.status(404).json({
    exito:   false,
    mensaje: "Ruta no encontrada. Verifica la URL y el método HTTP."
  });
});

/**
 * 500 - Error global del servidor.
 * Captura cualquier error no manejado que llegue hasta aquí.
 * @param {Error}    err
 * @param {Request}  req
 * @param {Response} res
 * @param {Function} next - Express requiere 4 parámetros para reconocer este manejador
 */
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error("[Error global]", err.message);
  res.status(500).json({
    exito:   false,
    mensaje: "Error interno del servidor."
  });
});

/* -------------------------------------------------------
   INICIAR EL SERVIDOR
   ------------------------------------------------------- */
app.listen(PORT, () => {
  console.log("========================================");
  console.log("  BarberTurno API — GA7-220501096-AA5  ");
  console.log("========================================");
  console.log(`  Servidor corriendo en http://localhost:${PORT}`);
  console.log("  Endpoints disponibles:");
  console.log(`  POST http://localhost:${PORT}/api/auth/registro`);
  console.log(`  POST http://localhost:${PORT}/api/auth/login`);
  console.log(`  GET  http://localhost:${PORT}/api/auth/perfil  (requiere JWT)`);
  console.log(`  GET  http://localhost:${PORT}/api/health`);
  console.log("========================================");
});

module.exports = app; /* Exportar para pruebas */
