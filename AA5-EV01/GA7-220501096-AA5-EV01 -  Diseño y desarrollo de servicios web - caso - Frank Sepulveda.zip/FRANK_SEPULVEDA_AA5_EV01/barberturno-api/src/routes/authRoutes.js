/**
 * BarberTurno API — Rutas de Autenticación
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Define las rutas públicas (sin token) para autenticación:
 *
 *   POST /api/auth/registro  → Registrar nuevo usuario
 *   POST /api/auth/login     → Iniciar sesión
 *   GET  /api/auth/perfil    → Ver perfil (ruta protegida de ejemplo)
 *
 * Estas rutas se montan en app.js bajo el prefijo /api/auth.
 */

"use strict";

const express = require("express");
const router  = express.Router();

/* Importar controladores y middleware */
const { registro, login }           = require("../controllers/authController");
const { verificarToken }            = require("../middleware/authMiddleware");
const Usuario                       = require("../models/Usuario");

/* -------------------------------------------------------
   RUTAS PÚBLICAS (no requieren token)
   ------------------------------------------------------- */

/**
 * POST /api/auth/registro
 * Registra un nuevo usuario en el sistema.
 *
 * Body (JSON):
 *   { "nombre": "...", "email": "...", "password": "..." }
 *
 * Respuesta exitosa (201):
 *   { exito: true, mensaje: "...", token: "...", usuario: {...} }
 *
 * Errores posibles:
 *   400 - Campos faltantes o contraseña muy corta
 *   409 - Email ya registrado
 *   500 - Error del servidor
 */
router.post("/registro", registro);

/**
 * POST /api/auth/login
 * Autentica un usuario existente.
 *
 * Body (JSON):
 *   { "email": "...", "password": "..." }
 *
 * Respuesta exitosa (200):
 *   { exito: true, mensaje: "Autenticación satisfactoria.", token: "...", usuario: {...} }
 *
 * Errores posibles:
 *   400 - Campos faltantes
 *   401 - Credenciales incorrectas (error en la autenticación)
 *   500 - Error del servidor
 */
router.post("/login", login);

/* -------------------------------------------------------
   RUTA PROTEGIDA (ejemplo de uso del middleware)
   ------------------------------------------------------- */

/**
 * GET /api/auth/perfil
 * Retorna los datos del usuario actualmente autenticado.
 * Requiere token JWT válido en el header Authorization.
 *
 * Header:
 *   Authorization: Bearer <token>
 *
 * Respuesta exitosa (200):
 *   { exito: true, usuario: { id, nombre, email, rol } }
 */
router.get("/perfil", verificarToken, (req, res) => {
  /* req.usuario contiene el payload del token (id, email, rol) */
  const usuario = Usuario.buscarPorId(req.usuario.id);

  if (!usuario) {
    return res.status(404).json({
      exito:   false,
      mensaje: "Usuario no encontrado."
    });
  }

  /* Excluir la contraseña de la respuesta */
  const { password, ...usuarioPublico } = usuario;
  return res.json({ exito: true, usuario: usuarioPublico });
});

module.exports = router;
