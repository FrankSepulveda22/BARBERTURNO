/**
 * BarberTurno API — Script de pruebas manuales
 * GA7-220501096-AA5-EV01
 * Autor: Frank Sepúlveda
 *
 * Ejecuta una serie de peticiones HTTP al servidor local para
 * verificar que los servicios de registro e inicio de sesión
 * funcionan correctamente en todos los escenarios posibles.
 *
 * Prerequisito: el servidor debe estar corriendo en el puerto 8080.
 *   node src/index.js
 *
 * Cómo ejecutar las pruebas:
 *   node test/auth.test.js
 */

"use strict";

const http = require("http");

/* URL base del servidor local */
const BASE_URL = "http://localhost:8080";

/* -------------------------------------------------------
   HELPER: Realizar petición HTTP
   ------------------------------------------------------- */

/**
 * Envía una petición HTTP al servidor y retorna la respuesta como JSON.
 * @param {string} metodo  - Método HTTP (GET, POST, etc.)
 * @param {string} ruta    - Ruta del endpoint (ej: "/api/auth/login")
 * @param {Object} [cuerpo] - Cuerpo de la petición (opcional)
 * @param {string} [token]  - Token JWT para rutas protegidas (opcional)
 * @returns {Promise<{status: number, datos: Object}>}
 */
function peticion(metodo, ruta, cuerpo = null, token = null) {
  return new Promise((resolve, reject) => {
    const cuerpoJSON = cuerpo ? JSON.stringify(cuerpo) : null;

    const opciones = {
      hostname: "localhost",
      port:     8080,
      path:     ruta,
      method:   metodo,
      headers: {
        "Content-Type": "application/json",
        ...(cuerpoJSON && { "Content-Length": Buffer.byteLength(cuerpoJSON) }),
        ...(token       && { "Authorization": `Bearer ${token}` })
      }
    };

    const req = http.request(opciones, (res) => {
      let raw = "";
      res.on("data", chunk => { raw += chunk; });
      res.on("end", () => {
        try {
          resolve({ status: res.statusCode, datos: JSON.parse(raw) });
        } catch {
          resolve({ status: res.statusCode, datos: raw });
        }
      });
    });

    req.on("error", reject);

    if (cuerpoJSON) req.write(cuerpoJSON);
    req.end();
  });
}

/* -------------------------------------------------------
   HELPER: Imprimir resultado de prueba
   ------------------------------------------------------- */

/**
 * Imprime en consola el resultado de un caso de prueba.
 * @param {string} nombre    - Nombre descriptivo del caso
 * @param {number} status    - Código HTTP recibido
 * @param {Object} datos     - Cuerpo de la respuesta
 * @param {boolean} esperado - true si el resultado era el esperado
 */
function imprimirResultado(nombre, status, datos, esperado) {
  const icono = esperado ? "✅" : "❌";
  console.log(`\n${icono} ${nombre}`);
  console.log(`   Status: ${status}`);
  console.log(`   Mensaje: ${datos.mensaje || "(sin mensaje)"}`);
  if (datos.token) {
    /* Mostrar solo los primeros 30 chars del token para no saturar la consola */
    console.log(`   Token: ${datos.token.substring(0, 30)}...`);
  }
}

/* -------------------------------------------------------
   CASOS DE PRUEBA
   ------------------------------------------------------- */

async function ejecutarPruebas() {
  console.log("========================================");
  console.log("  BarberTurno API — Pruebas de servicio ");
  console.log("  GA7-220501096-AA5-EV01               ");
  console.log("========================================");

  let tokenGuardado = null; /* Para reutilizar en la prueba de perfil */

  /* ===========================================================
     SECCIÓN 1: SERVICIO DE REGISTRO
     =========================================================== */
  console.log("\n--- SERVICIO DE REGISTRO (POST /api/auth/registro) ---");

  /* Caso 1: Registro exitoso con datos válidos */
  {
    const { status, datos } = await peticion("POST", "/api/auth/registro", {
      nombre:   "María García",
      email:    "maria@email.com",
      password: "segura123"
    });
    imprimirResultado(
      "Registro exitoso",
      status, datos,
      status === 201 && datos.exito === true
    );
  }

  /* Caso 2: Registro con email ya existente */
  {
    const { status, datos } = await peticion("POST", "/api/auth/registro", {
      nombre:   "Frank Sepúlveda",
      email:    "frank@email.com",  /* ya existe en la BD */
      password: "cualquier"
    });
    imprimirResultado(
      "Registro con email duplicado (debe fallar con 409)",
      status, datos,
      status === 409 && datos.exito === false
    );
  }

  /* Caso 3: Registro sin campos obligatorios */
  {
    const { status, datos } = await peticion("POST", "/api/auth/registro", {
      email: "incompleto@email.com"
      /* falta nombre y password */
    });
    imprimirResultado(
      "Registro con campos faltantes (debe fallar con 400)",
      status, datos,
      status === 400 && datos.exito === false
    );
  }

  /* Caso 4: Registro con contraseña muy corta */
  {
    const { status, datos } = await peticion("POST", "/api/auth/registro", {
      nombre:   "Test Usuario",
      email:    "test2@email.com",
      password: "123"  /* menos de 6 caracteres */
    });
    imprimirResultado(
      "Registro con contraseña muy corta (debe fallar con 400)",
      status, datos,
      status === 400 && datos.exito === false
    );
  }

  /* ===========================================================
     SECCIÓN 2: SERVICIO DE INICIO DE SESIÓN
     =========================================================== */
  console.log("\n--- SERVICIO DE INICIO DE SESIÓN (POST /api/auth/login) ---");

  /* Caso 5: Login exitoso con credenciales correctas */
  {
    const { status, datos } = await peticion("POST", "/api/auth/login", {
      email:    "frank@email.com",
      password: "1234"
    });
    imprimirResultado(
      "Login exitoso — Autenticación satisfactoria",
      status, datos,
      status === 200 && datos.exito === true
    );
    if (datos.token) tokenGuardado = datos.token;
  }

  /* Caso 6: Login con contraseña incorrecta */
  {
    const { status, datos } = await peticion("POST", "/api/auth/login", {
      email:    "frank@email.com",
      password: "wrongpassword"
    });
    imprimirResultado(
      "Login con contraseña incorrecta (debe retornar error en la autenticación)",
      status, datos,
      status === 401 && datos.exito === false
    );
  }

  /* Caso 7: Login con email no registrado */
  {
    const { status, datos } = await peticion("POST", "/api/auth/login", {
      email:    "noexiste@email.com",
      password: "cualquiera"
    });
    imprimirResultado(
      "Login con email no registrado (debe retornar error en la autenticación)",
      status, datos,
      status === 401 && datos.exito === false
    );
  }

  /* Caso 8: Login sin enviar ningún campo */
  {
    const { status, datos } = await peticion("POST", "/api/auth/login", {});
    imprimirResultado(
      "Login sin campos (debe fallar con 400)",
      status, datos,
      status === 400 && datos.exito === false
    );
  }

  /* ===========================================================
     SECCIÓN 3: RUTA PROTEGIDA (VERIFICACIÓN JWT)
     =========================================================== */
  console.log("\n--- RUTA PROTEGIDA (GET /api/auth/perfil) ---");

  /* Caso 9: Acceso con token válido */
  if (tokenGuardado) {
    const { status, datos } = await peticion("GET", "/api/auth/perfil", null, tokenGuardado);
    imprimirResultado(
      "Perfil con token válido",
      status, datos,
      status === 200 && datos.exito === true
    );
  }

  /* Caso 10: Acceso sin token */
  {
    const { status, datos } = await peticion("GET", "/api/auth/perfil");
    imprimirResultado(
      "Perfil sin token (debe fallar con 401)",
      status, datos,
      status === 401 && datos.exito === false
    );
  }

  /* Caso 11: Acceso con token inválido */
  {
    const { status, datos } = await peticion("GET", "/api/auth/perfil", null, "token.invalido.xyz");
    imprimirResultado(
      "Perfil con token inválido (debe fallar con 401)",
      status, datos,
      status === 401 && datos.exito === false
    );
  }

  console.log("\n========================================");
  console.log("  Pruebas completadas");
  console.log("========================================\n");
}

/* Ejecutar todas las pruebas */
ejecutarPruebas().catch(err => {
  console.error("\n❌ Error al ejecutar pruebas:", err.message);
  console.error("   ¿Está el servidor corriendo? Ejecuta: node src/index.js");
  process.exit(1);
});
