# BarberTurno API — Servicios Web de Autenticación
## GA7-220501096-AA5-EV01

**Aprendiz:** Frank Sepúlveda  
**Programa:** Análisis y Desarrollo de Software — SENA  
**Actividad:** GA7-220501096-AA5 — Crear servicios web, de acuerdo con el diseño.  
**Evidencia:** GA7-220501096-AA5-EV01 — Diseño y desarrollo de servicios web - caso.

---

## 📋 Descripción

API REST desarrollada en **Node.js + Express** que provee servicios web de autenticación para el sistema **BarberTurno**. Implementa los endpoints de registro e inicio de sesión con validaciones, encriptación de contraseñas y autenticación por tokens JWT.

---

## 🏗️ Estructura del proyecto

```
barberturno-api/
├── src/
│   ├── index.js                  → Punto de entrada, configuración Express
│   ├── config/
│   │   └── config.js             → Constantes (puerto, secreto JWT, bcrypt)
│   ├── models/
│   │   └── Usuario.js            → Modelo de datos (BD en memoria)
│   ├── controllers/
│   │   └── authController.js     → Lógica de registro e inicio de sesión
│   ├── middleware/
│   │   └── authMiddleware.js     → Verificación de token JWT
│   └── routes/
│       └── authRoutes.js         → Definición de endpoints
├── test/
│   └── auth.test.js              → Pruebas manuales de los servicios
├── .gitignore
├── package.json
└── README.md
```

---

## 🌐 Endpoints del servicio web

### Registro de usuario
```
POST /api/auth/registro
Content-Type: application/json

{
  "nombre":   "María García",
  "email":    "maria@email.com",
  "password": "segura123"
}
```

**Respuesta exitosa (201):**
```json
{
  "exito":   true,
  "mensaje": "Usuario registrado correctamente. ¡Bienvenido a BarberTurno!",
  "token":   "eyJhbGc...",
  "usuario": { "id": 3, "nombre": "María García", "email": "maria@email.com", "rol": "cliente" }
}
```

---

### Inicio de sesión
```
POST /api/auth/login
Content-Type: application/json

{
  "email":    "frank@email.com",
  "password": "1234"
}
```

**Respuesta exitosa (200):**
```json
{
  "exito":   true,
  "mensaje": "Autenticación satisfactoria. ¡Bienvenido, Frank Sepúlveda!",
  "token":   "eyJhbGc...",
  "usuario": { "id": 1, "nombre": "Frank Sepúlveda", "email": "frank@email.com", "rol": "cliente" }
}
```

**Error de autenticación (401):**
```json
{
  "exito":   false,
  "mensaje": "Error en la autenticación: credenciales incorrectas."
}
```

---

### Ver perfil (ruta protegida)
```
GET /api/auth/perfil
Authorization: Bearer <token>
```

---

## ▶️ Cómo ejecutar

### 1. Instalar dependencias
```bash
npm install
```

### 2. Iniciar el servidor
```bash
node src/index.js
```
El servidor queda disponible en `http://localhost:8080`

### 3. Ejecutar pruebas (con el servidor corriendo)
```bash
node test/auth.test.js
```

### 4. Credenciales de prueba predefinidas
| Email | Contraseña | Rol |
|---|---|---|
| frank@email.com | 1234 | cliente |
| admin@barberturno.com | admin123 | admin |

---

## 🔐 Validaciones implementadas

**Registro:**
- Campos obligatorios: nombre, email, password
- Contraseña mínima de 6 caracteres
- Formato de email válido
- Email no puede estar ya registrado (HTTP 409)

**Login:**
- Campos obligatorios: email, password
- Mensaje de error genérico para no revelar si el email existe
- Contraseña verificada contra hash bcrypt

---

## 🛠️ Tecnologías utilizadas

| Tecnología | Versión | Uso |
|---|---|---|
| Node.js | 18+ | Entorno de ejecución |
| Express | 4.18 | Framework HTTP |
| bcryptjs | 2.4 | Hashing de contraseñas |
| jsonwebtoken | 9.0 | Tokens JWT |

---

## 🔗 Repositorio

**GitHub:** https://github.com/FrankSepulveda22/BARBERTURNO

---

## ✅ Criterios de evaluación cubiertos

- [x] **Indicador 1:** Servicio web para registro de usuario implementado (`POST /api/auth/registro`)
- [x] **Indicador 2:** Servicio web para inicio de sesión implementado (`POST /api/auth/login`)
- [x] **Indicador 3:** Validaciones de verificación correctas (campos, formato, contraseñas, duplicados, JWT)
- [x] **Indicador 4:** Proyecto creado con herramientas de versionamiento (GitHub: FrankSepulveda22/BARBERTURNO)
- [x] Código con comentarios explicativos en todos los archivos
